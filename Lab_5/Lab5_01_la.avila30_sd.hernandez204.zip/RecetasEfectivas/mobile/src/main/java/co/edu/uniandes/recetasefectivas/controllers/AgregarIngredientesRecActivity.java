package co.edu.uniandes.recetasefectivas.controllers;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;

import co.edu.uniandes.recetasefectivas.R;

public class AgregarIngredientesRecActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_ingredientes);
    }


}
